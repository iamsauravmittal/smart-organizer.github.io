<?php $list = array (
  0 => 'Item 1',
  1 => 'Item 2',
  2 => 'Item 3',
);